
	var pater = document.getElementById('pater');

	document.getElementById('pater__remove').addEventListener('click',(e) => {
		e.preventDefault();
		pater.style.display = 'none';
	});